[vgl. Wiki/Testdatensatz](https://gitlab.ub.uni-bielefeld.de/medfak-diz/koop-plattform/wiki/-/wikis/Testdatensatz)
